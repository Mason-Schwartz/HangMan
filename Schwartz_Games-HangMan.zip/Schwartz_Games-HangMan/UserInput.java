import java.util.Scanner;
public class UserInput
{
    public static String getString()
    {
        Scanner in = new Scanner(System.in);
        return in.next();
    }
}